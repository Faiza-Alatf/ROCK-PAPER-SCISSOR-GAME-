#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

void displayScoreboard(int userScore, int computerScore, int rounds) {
    cout << "\nScoreboard\n";
    cout << "---------------------------\n";
    cout << "|   User   |   Computer   |\n";
    cout << "|    " << userScore << "     |       " << computerScore << "      |\n";
    cout << "---------------------------\n";
    cout << "Rounds played: " << rounds << "\n\n";
}
void display()
{
	cout << endl;
	cout << "\t Game rules : " << endl;
	cout << "\t -> Rock crushes the scissor" << endl;
	cout << "\t->scissor cuts the paper" << endl;
	cout << "\t ->paper covers the rock" << endl;
	cout << endl;
}

int main() {
	system("color 2");
	cout << ".................................................................................................................................................................\n\n"
		 << endl;
	cout << "_________________ ROCK , PAPER AND SCISSORS GAME___________________________\n\n"
		 << endl;
	display();
    srand(time(0)); // Seed for random number generation

    int userChoice;
    int computerChoice;
    int userScore = 0;
    int computerScore = 0;
    int rounds = 0;

    cout << "Let's play Rock, Paper, Scissors!\n";

    while (true) {
        cout << "\nEnter your choice:\n";
        cout << "1. Rock\n";
        cout << "2. Paper\n";
        cout << "3. Scissors\n";
        cout << "0. Exit game\n";
        cout << "Your choice: ";
        cin >> userChoice;

        // Validate user input
        while (userChoice < 0 || userChoice > 3) {
            cout << "Invalid choice! Please enter a number between 0 and 3: ";
            cin >> userChoice;
        }

        if (userChoice == 0) {
break; // Exit the game if the user chooses 0
        }

        // Generate random choice for computer
        computerChoice = rand() % 3 + 1;

        cout << "Computer chooses: ";
        switch (computerChoice) {
            case 1:
                cout << "Rock\n";
                break;
            case 2:
                cout << "Paper\n";
                break;
            case 3:
                cout << "Scissors\n";
                break;
        }

        // Determine the winner
        if (userChoice == computerChoice) {
            cout << "It's a tie!\n";
        } else if ((userChoice == 1 && computerChoice == 3) ||
                   (userChoice == 2 && computerChoice == 1) ||
                   (userChoice == 3 && computerChoice == 2)) {
            cout << "You win!\n";
            userScore++;
        } else {
            cout << "Computer wins!\n";
            computerScore++;
        }

        rounds++;

        // Display current scoreboard
        displayScoreboard(userScore, computerScore, rounds);
		system("pause");
		system("cls");
		cout << ".................................................................................................................................................................\n\n"
		 << endl;
	cout << "_________________ ROCK , PAPER AND SCISSORS GAME___________________________\n\n"
		 << endl;
	display();
		
    }

    // Display final scoreboard after exiting the game
    displayScoreboard(userScore, computerScore, rounds);
	if (userScore>computerScore)
	{
		cout<<"User Won!!!!!!\n";
	}
	else if(userScore==computerScore)
	{
		cout<<"Its a Tie\n";
	}
	else
	{
		cout<<"Computer Won!!!!!\n";
		cout<<"You loss!!!!!!\n";
	}
    cout << "Thanks for playing!\n";
	system("pause");

return 0;
}
